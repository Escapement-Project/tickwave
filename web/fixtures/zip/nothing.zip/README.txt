A capture and its notes.
